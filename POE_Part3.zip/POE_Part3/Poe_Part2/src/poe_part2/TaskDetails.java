package poe_part2;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class TaskDetails {
    Task task = new Task();
    
    // Arrays to store task details for Part 3 requirements
    private ArrayList<String> developerNamesList = new ArrayList<>();
    private ArrayList<String> taskNamesList = new ArrayList<>();
    private ArrayList<String> taskIDsList = new ArrayList<>();
    private ArrayList<Integer> taskDurationsList = new ArrayList<>();
    private ArrayList<String> taskStatusList = new ArrayList<>();

    // Variables to hold task details
    private static String task_name; 
    private static int chosen_option;
    private static int number_of_tasks;
    private static int task_duration;
    private static int task_number; 
    private static String task_description; 
    private static String developer_names; 
    private static String task_status;   
    static int total_hours = 0; 
    static String task_details;

    // Setters and Getters for task details
    public void setTask_name(String name) { task_name = name; }
    public String getTask_name() { return task_name; }
    
    public int getChosenOption() { return chosen_option; }
    public void setNumber_of_tasks(int number) { number_of_tasks = number; }
    public int getNumber_of_tasks() { return number_of_tasks; }
    
    public void setTask_duration(int duration) { task_duration = duration; }
    public int getTask_duration() { return task_duration; }

    public void setTask_description(String description) { task_description = description; }
    public String getTask_description() { return task_description; }
    
    public void setDeveloper_names(String names) { developer_names = names; }
    public String getDeveloper_names() { return developer_names; }
    
    public void setNumberOfCurrentTask(int task_number) { this.task_number = task_number; }
    public int getNumberOfCurrentTask() { return task_number; }
    
public void setTaskStatus() {
    boolean valid = false;
    while (!valid) {
        try {
            int option = Integer.parseInt(JOptionPane.showInputDialog(
                "Please choose the Status of this task:\n1) To Do\n2) Doing\n3) Done"));
            
            switch (option) {
                case 1:
                    task_status = "To Do";
                    valid = true;
                    break;
                case 2:
                    task_status = "Doing";
                    valid = true;
                    break;
                case 3:
                    task_status = "Done";
                    valid = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid selection! Please pick an option from 1 to 3.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input! Please enter a number.");
        }
    }
}


    public String getTask_status() { return task_status; }

    // Validation for task description length
    public void DescriptionStatus() {
        while (!(task.checkTaskDescription(getTask_description()))) {
            JOptionPane.showMessageDialog(null,"Please enter a task description of not more than 50 characters");
            setTask_description(JOptionPane.showInputDialog("Please enter a task description"));
        }
        JOptionPane.showMessageDialog(null, "Task Successfully captured.");
    }

    // Display Options including Part 3 functionalities
    public int welcomeAndChooseOption(boolean login) {  
    if (login) {
        JOptionPane.showMessageDialog(null, "Greetings and welcome to EasyKanban!\n");

        do {
            try {
                chosen_option = Integer.parseInt(JOptionPane.showInputDialog(
                        "PLEASE SELECT AN ACTION\n" +
                        "Option 1) Add new tasks\n" +
                        "Option 2) Search Task by Title\n" +
                        "Option 3) View Longest Task\n" +
                        "Option 4) Remove Task by Title\n" +
                        "Option 5) View Completed Tasks\n" +
                        "Option 6) Search Tasks by Developer Name\n" +
                        "Option 7) Show Report\n" +
                        "Option 8) Exit"));

                switch (chosen_option) {
                    case 1:
                        addTasks();
                        break;
                    case 2:
                        searchTaskByName();
                        break;
                    case 3:
                        displayLongestTask();
                        break;
                    case 4:
                        deleteTaskByName();
                        break;
                    case 5:
                        displayDoneTasks();
                        break;
                    case 6:
                        searchTasksByDeveloper();
                        break;
                    case 7:
                        displayReport();
                        break;
                    case 8:
                        JOptionPane.showMessageDialog(null, "Closing the application. Farewell!");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid choice! Please select a valid option.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input! Please enter a numeric value.");
            }
        } while (chosen_option != 8);
    }
    return chosen_option;
    }



    // Method to add tasks and store details in arrays
    public void addTasks() {
        setNumber_of_tasks(Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you want to add")));
        for (int i = 0; i < getNumber_of_tasks(); i++) {
            setTaskStatus();
            setNumberOfCurrentTask(i);
            setTask_name(JOptionPane.showInputDialog("Enter task name"));
            setTask_duration(Integer.parseInt(JOptionPane.showInputDialog("Enter the duration of this task")));
            setDeveloper_names(JOptionPane.showInputDialog("Please enter the developer's first name and surname"));
            setTask_description(JOptionPane.showInputDialog("Please enter a task description"));
            DescriptionStatus();

            // Store details in arrays
            developerNamesList.add(getDeveloper_names());
            taskNamesList.add(getTask_name());
            taskIDsList.add("ID-" + i);  // Example task ID generation
            taskDurationsList.add(getTask_duration());
            taskStatusList.add(getTask_status());

            // Display task details and update total hours
            JOptionPane.showMessageDialog(null, task.printTaskDetails(getTask_status(), getDeveloper_names(), getNumberOfCurrentTask(), getTask_name(), getTask_description(), getTask_duration()));
            total_hours += getTask_duration();
        }
        JOptionPane.showMessageDialog(null,"You need " + total_hours +" hours to complete these tasks.");
    }

    // a. Display tasks with status "done"
    public void displayDoneTasks() {
        StringBuilder doneTasks = new StringBuilder("Tasks with status 'Done':\n");
        boolean found = false;
        for (int i = 0; i < taskStatusList.size(); i++) {
            if (taskStatusList.get(i).equalsIgnoreCase("done")) {
                doneTasks.append("Developer: ").append(developerNamesList.get(i))
                         .append(", Task Name: ").append(taskNamesList.get(i))
                         .append(", Duration: ").append(taskDurationsList.get(i)).append(" hours\n");
                found = true;
            }
        }
        JOptionPane.showMessageDialog(null, found ? doneTasks.toString() : "No tasks with status 'Done'.");
    }

    // b. Display the Developer and Duration of the task with the longest duration
    public void displayLongestTask() {
        if (taskDurationsList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks available.");
            return;
        }
        int longestIndex = 0;
        for (int i = 1; i < taskDurationsList.size(); i++) {
            if (taskDurationsList.get(i) > taskDurationsList.get(longestIndex)) {
                longestIndex = i;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Task:\nDeveloper: " + developerNamesList.get(longestIndex) +
                                      ", Duration: " + taskDurationsList.get(longestIndex) + " hours");
    }

    // c. Search for a task by name
    public void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter the Task Name to search:");
        int index = taskNamesList.indexOf(taskName);
        if (index != -1) {
            JOptionPane.showMessageDialog(null, "Task found:\nTask Name: " + taskNamesList.get(index) +
                                          "\nDeveloper: " + developerNamesList.get(index) +
                                          "\nStatus: " + taskStatusList.get(index));
        } else {
            JOptionPane.showMessageDialog(null, "Task not found.");
        }
    }

    // d. Search for tasks by developer
    public void searchTasksByDeveloper() {
        String developerName = JOptionPane.showInputDialog("Enter the Developer's name to search tasks:");
        StringBuilder tasksByDeveloper = new StringBuilder("Tasks for Developer " + developerName + ":\n");
        boolean found = false;
        for (int i = 0; i < developerNamesList.size(); i++) {
            if (developerNamesList.get(i).equalsIgnoreCase(developerName)) {
                tasksByDeveloper.append("Task Name: ").append(taskNamesList.get(i))
                                .append(", Status: ").append(taskStatusList.get(i)).append("\n");
                found = true;
            }
        }
        JOptionPane.showMessageDialog(null, found ? tasksByDeveloper.toString() : "No tasks found for developer " + developerName + ".");
    }

    // e. Delete a task by name
    public void deleteTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter the Task Name to delete:");
        int index = taskNamesList.indexOf(taskName);
        if (index != -1) {
            developerNamesList.remove(index);
            taskNamesList.remove(index);
            taskIDsList.remove(index);
            taskDurationsList.remove(index);
            taskStatusList.remove(index);
            JOptionPane.showMessageDialog(null, "Task '" + taskName + "' deleted successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "Task not found.");
        }
    }

    // f. Display report of all tasks
    public void displayReport() {
        StringBuilder report = new StringBuilder("Task Report:\n");
        for (int i = 0; i < taskNamesList.size(); i++) {
            report.append("Task ID: ").append(taskIDsList.get(i))
                  .append(", Developer: ").append(developerNamesList.get(i))
                  .append(", Task Name: ").append(taskNamesList.get(i))
                  .append(", Duration: ").append(taskDurationsList.get(i))
                  .append(" hours, Status: ").append(taskStatusList.get(i)).append("\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }
}
