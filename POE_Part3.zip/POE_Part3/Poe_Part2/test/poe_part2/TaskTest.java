
package poe_part2;

import poe_part2.Task;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.Test;


public class TaskTest {
    Task task = new Task();
    public TaskTest() {
    }

    
    @Test
    public void testCheckTaskDescription() {
        boolean actual = task.checkTaskDescription("Create Login to authenticate users");
        boolean expected = true;
        assertEquals(expected, actual, "Task successfully captured");
    }

    @Test
    public void testCreateTaskID() {
        String actual = task.createTaskID("Robyn Harrison", "Add Task Feature", 1);
        String expected = "AD:1:BYN";
        
        assertEquals(expected, actual);
    }

    @Test
    public void testReturnTotalHours() {
    }
    
}
