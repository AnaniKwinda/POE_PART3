package poe_part2;

import poe_part2.Login;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


import org.junit.Test;


public class LoginTest {
    Login login = new Login();
    public LoginTest() {
    }

    @Test
    public void testCheckUserName() {
        assertTrue(login.checkUserName("kyl_1"));
        assertFalse(login.checkUserName("kyle!!!!!!!"));
       
        String expected = "kyl_1";
        String actual = login.u_name;
        
        assertEquals(expected, actual);
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(login.checkPasswordComplexity("password"));
        
        String expected = "Ch&&sec@ke99!";
        String actual = login.pass;
        
        assertEquals(expected, actual);
    }

    @Test
    public void testRegisterUser() {
    }

   
    @Test
    public void testReturnLoginStatus() {
    }
    
}
